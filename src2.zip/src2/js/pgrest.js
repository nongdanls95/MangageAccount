var PgREST={
	URL:"http://localhost:3000/",
	select:function(p,callback){
		$.ajax({
			type: "GET",
			url: PgREST.URL+p.table+p.where,
			headers: p.range?{Range: p.range,Prefer:"count=estimated"}:{},
			success: function(res, status, request){
				if (res !== null && res !== undefined){
					callback(res,request.getResponseHeader("Content-Range"));
				}
			},
			error: function(request, status, error){
				callback(error);
			}
		});
	}
}