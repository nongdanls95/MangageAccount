var _context={
	user:{},
	apps:{}
};
function body_onLoad(){
	$('#divMain').w2layout({
		name: 'divMain',
		panels: [
			{ type: 'top', size: '32px', content: '<b style="float:right"><img src="favicon.ico"/>&nbsp;NUC v1.0&nbsp;</b><div id="divTop"></div>' },
			{ type: 'left', size: '610px', resizable: true, content: '<div id="divLeft" class="full"><div id="divWindow"></div></div>' },
			{ type: 'main', content: '<div id="divMain" class="full"></div>' }
		]
	});
	var conf=LIB.configWindow(_testconf);
	conf.tabid=conf.windowid;
	buildWindow(divWindow,conf,0);
}

function buildForm(div,conf){
	var fields=[],columns=[];
	var i=0;
	for(var key in conf.fields)if(conf.fields.hasOwnProperty(key)){
		var field=conf.fields[key];
		if(field.isdisplay=="Y")
			fields.push({field: field.fieldname, type: field.fieldtype, required: field.isallownull=="N", html:{label:field.alias,column:i++%conf.layoutcolumn,attr:field.isreadonly=="Y"?"readonly":""}});
		if(field.isdisplaygrid=="Y")
			columns.push({field:field.fieldname,text:field.alias,size:"100px"});
	}
	
	var divTool=document.createElement("div");
	divTool.id="divtool_"+conf.tabid;
	div.appendChild(divTool);
	var divContent=document.createElement("div");
	divContent.id="divcont_"+conf.tabid;
	div.appendChild(divContent);
	//form
	var divForm=document.createElement("div");
	divForm.id="divform_"+conf.tabid;
	divContent.appendChild(divForm);
	$(divForm).w2form({name:divForm.id,fields:fields});
	//grid
	var divGrid=document.createElement("div");
	divGrid.id="divgrid_"+conf.tabid;
	divGrid.style.height=(divForm.style.height.length<5||divForm.style.height<"200px")?"200px":divForm.style.height;
	divContent.appendChild(divGrid);
	$(divGrid).w2grid({name:divGrid.id,columns:columns});
	divGrid.style.display="none";
	
	//toolbar
	$(divTool).w2toolbar({
		name: divTool.id,
		items: [{type:'check',id:"GRID",icon:'table',tooltip:"Form/Grid"},
				{type:'button',id:"FIND",icon:'find',tooltip:"Find"},
				{type:'spacer'},
				{type:'check',id:"EXPD",text:"«",tooltip:"Collapse"}],
		onClick:tool_onClick,
		tag:conf
	});
}
function buildWindow(div,conf,tabLevel){
	var divTabs=document.createElement("div");
	divTabs.id="divtabs_"+conf.tabid+"_"+tabLevel;
	div.appendChild(divTabs);
	
	var tabs=[];
	for(var key in conf.tabs)if(conf.tabs.hasOwnProperty(key)){
		var tab=conf.tabs[key];
		tab.layoutcolumn=2;
		if(tab.tablevel==tabLevel){
			var divTab=document.createElement("div");
			divTab.id="divtab_"+tab.tabid;
			if(tabs.length)divTab.style.display="none";
			div.appendChild(divTab);
			tabs.push({id:tab.tabid,text:tab.tabname,tag:tab});
		}
	};
	if(tabs.length){
		var tabstrip=$(divTabs).w2tabs({
			name: divTabs.id,
			active: tabs[0].id,
			tabs: tabs,
			onClick: tab_onClick
		});
		tabstrip.onClick({tab:tabstrip.tabs[0]});
	}
}
function tab_onClick(evt){
	var conf=evt.tab.tag;
	for(var i=0;i<this.tabs.length;i++){
		var tab=this.tabs[i];
		document.getElementById("divtab_"+tab.id).style.display=(tab.id==conf.tabid)?"":"none";
	}
	if(!evt.tab.isBuilt){
		var div=document.getElementById("divtab_"+conf.tabid);
		buildForm(div,conf);
		if(Object.keys(conf.tabs).length)
			for(var l=1;l<=conf.maxLevel;l++)buildWindow(div,conf,l);
		evt.tab.isBuilt=true;
	}
}
function tool_onClick(evt){
	var item=evt.item;
	var conf=this.tag;
	var divContent=document.getElementById("divcont_"+conf.tabid);
	var form=w2ui["divform_"+conf.tabid];
	var grid=w2ui["divgrid_"+conf.tabid];
	switch(item.id){
		case "EXPD":
			divContent.style.display=item.checked?"":"none";
			break;
		case "GRID":
			form.box.style.display=item.checked?"":"none";
			grid.box.style.display=item.checked?"none":"";
			if(item.checked)form.resize();else grid.resize();
			break;
		case "FIND":
			var id="divfind_"+conf.tabid;
			w2popup.open({
				title: 'Find',
				modal: false,
				width: 610,
				height: divContent.clientHeight+100,
				body: '<div id="'+id+'" class="full"></div>',
				onOpen:function(evt){
					evt.onComplete=function(){
						var div=document.getElementById(id);
						if(w2ui[id])w2ui[id].render(div);
						else $(div).w2form({ 
							name: id,
							fields: form.fields,
							actions: {
								Find: function (evt) {
									var where=LIB.calcWhere(evt.record);
									PgREST.select({table:conf.tablename,where:where,range:"0-19"},function(res){
										grid.records=res;
										grid.refresh();
									});
									w2popup.close();
								},
								Close: function () {
									w2popup.close();
								}
							}
						});
					}
				}
			});
			break;
	}
}