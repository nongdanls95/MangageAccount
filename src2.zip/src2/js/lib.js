var _sys={
	window:["windowid","description","windowname","windowtype","applicationid","layoutcolumn"],
	tab:["tabid","parenttabid","tabname","description","tablevel","orderno","truonglienketcon","truonglienketcha","whereclause","orderbyclause","tableid","windowid","truongtrunggiancon","truongtrunggiancha","bangchaid","tablename"],
	field:["fieldid","fieldname","alias","isdisplaygrid","isdisplay","displaylength","orderno","isreadonly","fieldlength","vformat","defaultvalue","isallownull","isunique","fieldgroup","tabid","columnid","fieldtype"]
};
var LIB={
	configWindow:function(conf){
		var winconf={tabs:{}};
		for(var i=0;i<_sys.window.length;i++)
			winconf[_sys.window[i]]=conf.window[i];
		
		var lookup={};
		for(var i=0;i<conf.tabs.length;i++){
			var tab={fields:{},tabs:{},maxLevel:0};
			for(var j=0;j<_sys.tab.length;j++)tab[_sys.tab[j]]=conf.tabs[i][j];
			winconf.tabs[tab.tabid]=tab;
			if(tab.parenttabid){
				winconf.tabs[tab.parenttabid].tabs[tab.tabid]=tab;
				if(tab.tablevel>winconf.tabs[tab.parenttabid].maxLevel)winconf.tabs[tab.parenttabid].maxLevel=tab.tablevel;
			}
		}
		for(var i=0;i<conf.fields.length;i++){
			var field={};
			for(var j=0;j<_sys.field.length;j++)field[_sys.field[j]]=conf.fields[i][j];
			winconf.tabs[field.tabid].fields[field.fieldid]=field;
		}
		return winconf;
	},
	calcWhere:function(rec){
		var where="";
		for(var key in rec)if(rec.hasOwnProperty(key)){
			where=where?where+"&"+key+"=like."+rec[key]:key+"=like."+rec[key];
		}
		return where;
	}
}